// ==UserScript==
// @name         Margonem - Panel dodatkow
// @namespace    local.codex.margonem.panel
// @version      1.0.0
// @description  Wspolna zwijana belka dla niezaleznych dodatkow Margonem.
// @match        http*://*.margonem.pl/*
// @grant        none
// ==/UserScript==

(() => {
    'use strict';

    const STORAGE_KEY = 'codex_addon_panel_collapsed';
    const BUTTON_IDS = [
        'codex-auto-bless-button',
        'Auto-X-launcher',
        'codex-ulepszarka-launcher'
    ];
    let collapsed = localStorage.getItem(STORAGE_KEY) === '1';

    const style = document.createElement('style');
    style.textContent = `
#codex-addon-dock {
position:fixed;
z-index:2147483640;
width:26px;
display:flex;
flex-direction:column;
align-items:stretch;
font-family:Arial,Helvetica,sans-serif;
}
#codex-addon-dock-toggle {
position:relative;
z-index:2;
width:26px;
height:14px;
padding:0;
color:#ddd;
background:rgba(18,18,18,.97);
border:1px solid #666;
border-radius:3px 3px 0 0;
cursor:pointer;
font:700 10px/12px Arial,Helvetica,sans-serif;
}
#codex-addon-dock-items {
display:flex;
flex-direction:column;
max-height:260px;
opacity:1;
overflow:hidden;
transform:translateY(0);
transform-origin:top center;
transition:max-height 260ms ease,opacity 220ms ease,transform 260ms ease;
}
#codex-addon-dock.collapsed #codex-addon-dock-items {
max-height:0;
opacity:0;
transform:translateY(-78px);
pointer-events:none;
}
#codex-addon-dock-items > button {
position:static!important;
inset:auto!important;
flex:0 0 26px!important;
width:26px!important;
height:26px!important;
min-width:26px!important;
min-height:26px!important;
margin:0!important;
padding:0!important;
border-radius:0!important;
transform:none!important;
visibility:visible!important;
pointer-events:auto!important;
}
#codex-addon-dock-items > button:last-child {
border-radius:0 0 3px 3px!important;
}`;

    const createPanel = () => {
        if (!document.body || document.getElementById('codex-addon-dock')) return;

        document.head.append(style);
        const dock = document.createElement('div');
        dock.id = 'codex-addon-dock';
        const toggle = document.createElement('button');
        toggle.id = 'codex-addon-dock-toggle';
        toggle.type = 'button';
        toggle.title = 'Zwin lub rozwin dodatki';
        const items = document.createElement('div');
        items.id = 'codex-addon-dock-items';
        dock.append(toggle, items);
        document.body.append(dock);

        const render = () => {
            dock.classList.toggle('collapsed', collapsed);
            toggle.textContent = collapsed ? '▼' : '▲';
            toggle.setAttribute('aria-expanded', String(!collapsed));
            if (collapsed) {
                document.getElementById('Auto-X')?.setAttribute('hidden', '');
                document.getElementById('codex-auto-bless')?.setAttribute('hidden', '');
                const upgradePanel = document.getElementById('codex-ulepszarka-panel');
                if (upgradePanel) upgradePanel.style.display = 'none';
            }
        };

        const collectButtons = () => {
            for (const id of BUTTON_IDS) {
                const button = document.getElementById(id);
                if (button && button.parentElement !== items) items.append(button);
            }
        };

        const position = () => {
            const game = document.querySelector('#game, #centerbox, #centerbox2, #base, #background, .game-window, .game-container, canvas');
            const rect = game?.getBoundingClientRect() || { left: 0, top: 0 };
            dock.style.left = `${Math.max(0, Math.round(rect.left))}px`;
            dock.style.top = `${Math.max(0, Math.round(rect.top))}px`;
        };

        toggle.addEventListener('click', event => {
            event.preventDefault();
            event.stopPropagation();
            collapsed = !collapsed;
            localStorage.setItem(STORAGE_KEY, collapsed ? '1' : '0');
            render();
        });

        const observer = new MutationObserver(() => {
            collectButtons();
            position();
        });
        observer.observe(document.body, { childList: true, subtree: true });
        window.addEventListener('resize', position, { passive: true });
        window.setInterval(() => {
            collectButtons();
            position();
        }, 1000);

        collectButtons();
        position();
        render();
    };

    if (document.body) createPanel();
    else document.addEventListener('DOMContentLoaded', createPanel, { once: true });
})();
